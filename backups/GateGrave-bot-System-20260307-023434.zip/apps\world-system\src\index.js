"use strict";

const { handleWorldEventByType } = require("./handlers");

module.exports = {
  handleWorldEventByType
};
