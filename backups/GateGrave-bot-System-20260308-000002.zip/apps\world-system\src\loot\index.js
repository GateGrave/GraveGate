"use strict";

const { LOOT_DROP_SCHEMA, createLootDropRecord } = require("./loot-drop.schema");
const { InMemoryLootDropStore, LootDropManager } = require("./loot-drop.manager");
const { LOOT_TABLE_SCHEMA, createLootTableRecord } = require("./loot-table.schema");
const {
  InMemoryLootTableStore,
  LootTableManager,
  createExampleLootTables
} = require("./loot-table.manager");
const { resolveLootRoll } = require("./loot-roll.resolver");
const {
  ProcessedEnemyDefeatStore,
  processEnemyDefeatedRewardHook
} = require("./hooks/enemy-defeat-reward.hook");
const { processBossDefeatedRewardHook } = require("./hooks/boss-defeat-reward.hook");
const { applyGeneratedLootToInventory, InventoryGrantAdapter } = require("./grants/loot-grant.service");
const { LootLogger } = require("./loot-logger");
const { LootSimulationRunner } = require("./testing/loot-simulation-runner");

// Default in-memory manager for scaffolding usage.
const defaultLootDropManager = new LootDropManager();
const defaultLootTableManager = new LootTableManager();

function createLootDrop(input) {
  return defaultLootDropManager.createLootDrop(input);
}

function getLootDrop(loot_id) {
  return defaultLootDropManager.getLootDrop(loot_id);
}

function updateLootDrop(loot_id, updater) {
  return defaultLootDropManager.updateLootDrop(loot_id, updater);
}

function deleteLootDrop(loot_id) {
  return defaultLootDropManager.deleteLootDrop(loot_id);
}

function listLootDropsBySource(source_type, source_id) {
  return defaultLootDropManager.listLootDropsBySource(source_type, source_id);
}

function createLootTable(input) {
  return defaultLootTableManager.createLootTable(input);
}

function getLootTable(table_id) {
  return defaultLootTableManager.getLootTable(table_id);
}

function updateLootTable(table_id, updater) {
  return defaultLootTableManager.updateLootTable(table_id, updater);
}

function deleteLootTable(table_id) {
  return defaultLootTableManager.deleteLootTable(table_id);
}

function rollFromLootTable(table_id, options) {
  return defaultLootTableManager.rollFromLootTable(table_id, options);
}

module.exports = {
  LOOT_DROP_SCHEMA,
  LOOT_TABLE_SCHEMA,
  createLootDropRecord,
  createLootTableRecord,
  InMemoryLootDropStore,
  InMemoryLootTableStore,
  LootDropManager,
  LootTableManager,
  defaultLootDropManager,
  defaultLootTableManager,
  createLootDrop,
  getLootDrop,
  updateLootDrop,
  deleteLootDrop,
  listLootDropsBySource,
  createLootTable,
  getLootTable,
  updateLootTable,
  deleteLootTable,
  rollFromLootTable,
  createExampleLootTables,
  resolveLootRoll,
  ProcessedEnemyDefeatStore,
  processEnemyDefeatedRewardHook,
  processBossDefeatedRewardHook,
  InventoryGrantAdapter,
  applyGeneratedLootToInventory,
  LootLogger,
  LootSimulationRunner
};
