"use strict";

const { InMemoryInventoryStore, InMemoryItemStore } = require("../../../../database/src/world-storage");
const { LootTableManager, createExampleLootTables } = require("../loot-table.manager");
const { processEnemyDefeatedRewardHook } = require("../hooks/enemy-defeat-reward.hook");
const { processBossDefeatedRewardHook } = require("../hooks/boss-defeat-reward.hook");
const { resolveLootRoll } = require("../loot-roll.resolver");
const { applyGeneratedLootToInventory } = require("../grants/loot-grant.service");
const { LootDropManager } = require("../loot-drop.manager");
const { LootLogger } = require("../loot-logger");

class LootSimulationRunner {
  constructor(options) {
    this.options = options || {};
    this.logs = [];
    this.step = 0;

    this.lootTableManager = new LootTableManager();
    this.lootDropManager = new LootDropManager();
    this.lootLogger = new LootLogger();
    this.worldStorage = {
      inventories: new InMemoryInventoryStore(),
      items: new InMemoryItemStore()
    };
  }

  log(kind, data) {
    this.step += 1;
    this.logs.push({
      step: this.step,
      kind,
      timestamp: new Date().toISOString(),
      data
    });
  }

  setupMocks() {
    this.mockPlayers = [
      { player_id: "char-001", inventory_id: "inv-char-001" },
      { player_id: "char-002", inventory_id: "inv-char-002" },
      { player_id: "char-003", inventory_id: "inv-char-003" }
    ];

    const tables = createExampleLootTables();
    this.lootTableManager.createLootTable(tables.normal_enemy);
    this.lootTableManager.createLootTable(tables.boss);
    this.lootTableManager.createLootTable(tables.future_chest);

    // Add a balancing table with stronger weighted spread.
    this.lootTableManager.createLootTable({
      table_id: "table-enemy-bandit-weights-001",
      source_type: "enemy",
      source_id: "bandit",
      possible_drops: [
        { item_id: "item-rag", quantity: 1, rarity: "common" },
        { item_id: "item-silver", quantity: { min: 1, max: 3 }, rarity: "uncommon" },
        { item_id: "item-map-fragment", quantity: 1, rarity: "rare" }
      ],
      drop_weights: {
        "item-rag": 70,
        "item-silver": 25,
        "item-map-fragment": 5
      },
      guaranteed_drops: [],
      rarity_rules: { default_roll_count: 4 }
    });

    // Seed item catalog for grant stage.
    const allItemIds = new Set();
    this.lootTableManager.store.list().forEach((table) => {
      table.possible_drops.forEach((drop) => allItemIds.add(drop.item_id));
      table.guaranteed_drops.forEach((drop) => allItemIds.add(drop.item_id));
    });

    for (const itemId of allItemIds) {
      let item_type = "stackable";
      if (itemId.includes("staff") || itemId.includes("ring") || itemId.includes("key")) item_type = "equipment";
      if (itemId.includes("potion")) item_type = "consumable";
      if (itemId.includes("arcane") || itemId.includes("enchanted")) item_type = "magical";
      if (itemId.includes("mysterious") || itemId.includes("unknown")) item_type = "unidentified";

      this.worldStorage.items.saveItem({
        item_id: itemId,
        item_type,
        rarity: "common"
      });
    }

    this.log("setup_complete", {
      players: this.mockPlayers,
      loot_tables: this.lootTableManager.store.list().map((x) => x.table_id),
      item_catalog_count: allItemIds.size
    });
  }

  scenarioNormalEnemyDefeat() {
    const event = {
      event_id: "evt-enemy-001",
      event_type: "enemy_defeated",
      session_id: "sess-loot-001",
      party_id: "party-001",
      player_id: this.mockPlayers[0].player_id,
      combat_id: "combat-001",
      payload: {
        enemy_id: "goblin"
      }
    };

    const generated = processEnemyDefeatedRewardHook({
      event,
      lootTableManager: this.lootTableManager,
      rng: () => 0.08
    });

    this.log("enemy_defeat_loot_generated", generated);
    if (generated.ok) this.lootLogger.logLootRolled(generated.payload.loot_result);
    return generated;
  }

  scenarioBossDefeat() {
    const event = {
      event_id: "evt-boss-001",
      event_type: "boss_defeated",
      session_id: "sess-loot-001",
      party_id: "party-001",
      player_id: this.mockPlayers[0].player_id,
      combat_id: "combat-002",
      payload: {
        boss_id: "lich-king",
        include_bonus_weighted: true,
        bonus_roll_count: 2
      }
    };

    const generated = processBossDefeatedRewardHook({
      event,
      lootTableManager: this.lootTableManager,
      rng: () => 0.2
    });

    this.log("boss_defeat_loot_generated", generated);
    if (generated.ok) this.lootLogger.logLootRolled(generated.payload.loot_result);
    return generated;
  }

  scenarioWeightedLootGeneration() {
    const weighted = resolveLootRoll({
      source_type: "enemy",
      source_id: "bandit",
      loot_table_id: "table-enemy-bandit-weights-001",
      context: {
        session_id: "sess-loot-001",
        player_id: this.mockPlayers[0].player_id
      },
      roll_count: 6,
      lootTableManager: this.lootTableManager
    });

    this.log("weighted_loot_roll", weighted);
    if (weighted.ok) this.lootLogger.logLootRolled(weighted.payload);
    return weighted;
  }

  scenarioInventoryGrant(generatedLootPayload, player) {
    const result = applyGeneratedLootToInventory({
      loot_payload: generatedLootPayload,
      inventory_id: player.inventory_id,
      owner_character_id: player.player_id,
      worldStorage: this.worldStorage,
      lootDropManager: this.lootDropManager
    });

    this.log("inventory_grant_result", {
      player_id: player.player_id,
      inventory_id: player.inventory_id,
      result
    });

    if (result.event_type === "loot_grant_success" || result.event_type === "loot_grant_partial_success") {
      this.lootLogger.logLootGranted(result.payload);
    }
    if (result.event_type === "loot_grant_failed" || result.payload?.status === "partial_success") {
      this.lootLogger.logLootGrantFailed(result.payload);
    }

    return result;
  }

  scenarioIndividualLootAssignment(generatedLootPayload) {
    const allDrops = generatedLootPayload?.loot_result?.all_drops || [];
    const buckets = this.mockPlayers.map((player) => ({
      player,
      drops: []
    }));

    // Round-robin assignment for individual distribution.
    allDrops.forEach((drop, index) => {
      buckets[index % buckets.length].drops.push(drop);
    });

    const grantResults = buckets.map((bucket) =>
      this.scenarioInventoryGrant(
        {
          ...generatedLootPayload,
          player_id: bucket.player.player_id,
          loot_result: {
            ...generatedLootPayload.loot_result,
            all_drops: bucket.drops
          }
        },
        bucket.player
      )
    );

    this.log("individual_assignment_complete", {
      assigned_counts: buckets.map((b) => ({
        player_id: b.player.player_id,
        drops: b.drops.length
      })),
      grant_statuses: grantResults.map((r) => r.payload?.status || "failure")
    });

    return grantResults;
  }

  runAllScenarios() {
    this.setupMocks();

    const normalEnemy = this.scenarioNormalEnemyDefeat();
    const boss = this.scenarioBossDefeat();
    const weighted = this.scenarioWeightedLootGeneration();

    if (normalEnemy.ok) {
      this.scenarioInventoryGrant(normalEnemy.payload, this.mockPlayers[0]);
    }

    if (boss.ok) {
      this.scenarioIndividualLootAssignment(boss.payload);
    }

    this.log("final_inventories", this.mockPlayers.map((player) => ({
      player_id: player.player_id,
      inventory: this.worldStorage.inventories.loadInventory(player.inventory_id)
    })));

    this.log("loot_log_records", this.lootLogger.listLogs());

    return {
      ok: true,
      scenarios: {
        normal_enemy_defeat: normalEnemy.ok,
        boss_defeat: boss.ok,
        weighted_loot_generation: weighted.ok,
        guaranteed_drops: Boolean(boss.payload?.guaranteed_drop_count > 0),
        individual_assignment: true,
        inventory_granting: true
      },
      logs: this.logs
    };
  }
}

if (require.main === module) {
  const result = new LootSimulationRunner().runAllScenarios();
  console.log(JSON.stringify(result, null, 2));
}

module.exports = {
  LootSimulationRunner
};
