$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$backupDir = Join-Path $projectRoot "backups"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$zipPath = Join-Path $backupDir ("GateGrave-bot-System-" + $timestamp + ".zip")

# Exclude the backup folder itself to avoid recursive zip issues.
$itemsToBackup = Get-ChildItem -Path $projectRoot -Force | Where-Object { $_.Name -ne "backups" }
Compress-Archive -Path $itemsToBackup.FullName -DestinationPath $zipPath -CompressionLevel Optimal -Force

Write-Output "Backup created: $zipPath"
