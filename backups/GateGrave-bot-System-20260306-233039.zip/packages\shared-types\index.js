"use strict";

// Single entry point so other files can import shared event helpers from one place.
const { EVENT_VERSION, REQUIRED_EVENT_FIELDS, createEvent, isValidEvent } = require("./event-schema");
const { EVENT_TYPES } = require("./event-types");
const { STATE_LAYERS, EVENT_FLOW_NOTES } = require("./state-layer-notes");

module.exports = {
  EVENT_VERSION,
  REQUIRED_EVENT_FIELDS,
  EVENT_TYPES,
  STATE_LAYERS,
  EVENT_FLOW_NOTES,
  createEvent,
  isValidEvent
};
