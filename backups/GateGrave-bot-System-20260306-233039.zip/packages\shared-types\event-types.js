"use strict";

// Shared event type constants for Phase 1 scaffolding.
// Keep these names stable so routing stays simple and predictable.
const EVENT_TYPES = {
  // Required examples for the shared format scaffold.
  PLAYER_MOVE: "player_move",
  PLAYER_ATTACK: "player_attack",
  COMBAT_STARTED: "combat_started",
  LOOT_GENERATED: "loot_generated",

  // Extra scaffold events used by current placeholder modules.
  PLAYER_CAST_SPELL: "player_cast_spell",
  LEVEL_UP: "level_up",
  DATABASE_EVENT_SAVED: "database_event_saved"
};

module.exports = {
  EVENT_TYPES
};
