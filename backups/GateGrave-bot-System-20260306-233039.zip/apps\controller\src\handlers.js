"use strict";

// Placeholder handler for world-level events.
// In later phases, this will emit follow-up events instead of calling other systems directly.
function handleWorldEvent(event, context) {
  void event;
  void context;
  return [];
}

// Placeholder handler for session-level events.
// Session logic is intentionally not implemented in this scaffold.
function handleSessionEvent(event, context) {
  void event;
  void context;
  return [];
}

// Placeholder handler for combat-level events.
// Combat logic is intentionally not implemented in this scaffold.
function handleCombatEvent(event, context) {
  void event;
  void context;
  return [];
}

module.exports = {
  handleWorldEvent,
  handleSessionEvent,
  handleCombatEvent
};
