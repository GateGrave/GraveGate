"use strict";

const { InventoryGrantAdapter } = require("../loot/grants/inventory-grant.adapter");
const { resolveCraftCompletion } = require("./craft-completion.resolver");
const { getMissingMaterials } = require("./resource-requirements");

class ProcessedCraftFinalizationStore {
  constructor() {
    this.processed = new Set();
  }

  has(key) {
    if (!key) return false;
    return this.processed.has(String(key));
  }

  add(key) {
    if (!key) return;
    this.processed.add(String(key));
  }
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function createFailure(reason, extra) {
  return {
    ok: false,
    event_type: "craft_finalize_failed",
    payload: {
      reason,
      ...(extra || {})
    }
  };
}

function normalizeRecipeRequirements(recipe) {
  if (!recipe || !Array.isArray(recipe.required_materials)) return [];

  return recipe.required_materials.map((row, index) => {
    if (!row || typeof row !== "object") {
      throw new Error("required_materials row must be object at index " + index);
    }
    if (row.item_id) {
      const quantity = Math.floor(Number(row.quantity));
      if (!Number.isFinite(quantity) || quantity <= 0) {
        throw new Error("required_materials quantity must be > 0 at index " + index);
      }
      return { type: "single", item_id: String(row.item_id), quantity };
    }

    if (Array.isArray(row.alternatives)) {
      if (row.alternatives.length === 0) {
        throw new Error("required_materials alternatives cannot be empty at index " + index);
      }
      return {
        type: "alternatives",
        alternatives: row.alternatives.map((alt, altIndex) => {
          if (!alt || typeof alt !== "object" || !alt.item_id) {
            throw new Error("alternative requires item_id at index " + index + ":" + altIndex);
          }
          const quantity = Math.floor(Number(alt.quantity));
          if (!Number.isFinite(quantity) || quantity <= 0) {
            throw new Error("alternative quantity must be > 0 at index " + index + ":" + altIndex);
          }
          return { item_id: String(alt.item_id), quantity };
        })
      };
    }

    throw new Error("required_materials requires item_id or alternatives at index " + index);
  });
}

function toRequirementInventoryView(inventory) {
  const entries = Array.isArray(inventory?.item_entries) ? inventory.item_entries : [];
  const quantities = {};
  entries.forEach((entry) => {
    if (!entry || !entry.item_id) return;
    const qty = Number.isFinite(entry.quantity) ? Math.floor(entry.quantity) : 1;
    if (qty <= 0) return;
    const key = String(entry.item_id);
    quantities[key] = (quantities[key] || 0) + qty;
  });
  return { quantities };
}

function totalOwned(entries, itemId) {
  const rows = Array.isArray(entries) ? entries : [];
  return rows
    .filter((entry) => entry.item_id === itemId)
    .reduce((sum, entry) => {
      const quantity = Number.isFinite(entry.quantity) ? Math.floor(entry.quantity) : 1;
      return sum + Math.max(0, quantity);
    }, 0);
}

function consumeFromEntries(entries, itemId, quantity) {
  let remaining = quantity;
  for (const entry of entries) {
    if (entry.item_id !== itemId) continue;
    if (remaining <= 0) break;

    const entryQty = Number.isFinite(entry.quantity) ? Math.max(0, Math.floor(entry.quantity)) : 1;
    if (entryQty <= remaining) {
      entry.quantity = 0;
      remaining -= entryQty;
    } else {
      entry.quantity = entryQty - remaining;
      remaining = 0;
    }
  }

  return remaining === 0;
}

function consumeRequiredMaterials(inventory, recipe) {
  const requirements = normalizeRecipeRequirements(recipe);
  const working = clone(Array.isArray(inventory.item_entries) ? inventory.item_entries : []);
  const consumed = [];

  for (const req of requirements) {
    if (req.type === "single") {
      const ok = consumeFromEntries(working, req.item_id, req.quantity);
      if (!ok) {
        return { ok: false, reason: "consume_failed", item_id: req.item_id, quantity: req.quantity };
      }
      consumed.push({ item_id: req.item_id, quantity: req.quantity });
      continue;
    }

    // Alternative material choice: first alternative with enough quantity.
    const chosen = req.alternatives.find((alt) => totalOwned(working, alt.item_id) >= alt.quantity);
    if (!chosen) {
      return { ok: false, reason: "consume_alternative_failed", alternatives: req.alternatives };
    }

    const ok = consumeFromEntries(working, chosen.item_id, chosen.quantity);
    if (!ok) {
      return { ok: false, reason: "consume_alternative_failed", alternatives: req.alternatives };
    }
    consumed.push({ item_id: chosen.item_id, quantity: chosen.quantity, consumed_as_alternative: true });
  }

  return {
    ok: true,
    item_entries_after: working.filter((entry) => {
      const quantity = Number.isFinite(entry.quantity) ? Math.floor(entry.quantity) : 1;
      return quantity > 0;
    }),
    consumed_materials: consumed
  };
}

function finalizeCraftWithResourceConsumption(input) {
  const data = input || {};
  const worldStorage = data.worldStorage || null;
  const inventoryStore = data.inventoryStore || worldStorage?.inventories || null;
  const itemStore = data.itemStore || worldStorage?.items || null;
  const processedStore = data.processedFinalizationStore || null;
  const allowDuplicate = data.allow_duplicate === true;

  if (!inventoryStore) {
    return createFailure("inventory_store_required");
  }

  const craftJob = data.craft_job;
  const recipe = data.recipe;
  if (!craftJob || !recipe) {
    return createFailure("craft_job_and_recipe_required");
  }

  const craft_job_id = String(craftJob.craft_job_id || "");
  if (!craft_job_id) {
    return createFailure("craft_job_id_required");
  }

  const finalizationKey =
    data.finalization_key ||
    data.event_id ||
    craft_job_id;

  if (!allowDuplicate && processedStore && typeof processedStore.has === "function") {
    if (processedStore.has(finalizationKey)) {
      return {
        ok: true,
        event_type: "craft_finalize_skipped",
        payload: {
          reason: "duplicate_finalization_attempt",
          finalization_key: String(finalizationKey),
          craft_job_id
        }
      };
    }
  }

  const completion = resolveCraftCompletion(
    { craft_job: craftJob, recipe },
    { allow_duplicate: true }
  );
  if (!completion.ok) {
    return createFailure("craft_completion_invalid", {
      completion_result: completion
    });
  }

  const inventory_id = data.inventory_id || `inv-${craftJob.player_id || "unknown"}`;
  const inventory = inventoryStore.loadInventory(inventory_id);
  if (!inventory) {
    return createFailure("inventory_not_found", {
      inventory_id
    });
  }

  const missingMaterials = getMissingMaterials(recipe, toRequirementInventoryView(inventory));
  if (missingMaterials.length > 0) {
    return createFailure("insufficient_materials", {
      craft_job_id,
      inventory_id,
      missing_materials: missingMaterials
    });
  }

  const beforeInventory = clone(inventory);
  const consumption = consumeRequiredMaterials(inventory, recipe);
  if (!consumption.ok) {
    return createFailure("material_consume_failed", {
      inventory_id,
      consume_result: consumption
    });
  }

  const consumedInventory = {
    ...beforeInventory,
    item_entries: consumption.item_entries_after
  };

  try {
    inventoryStore.saveInventory(consumedInventory);
  } catch (error) {
    return createFailure("material_consume_persist_failed", {
      message: error.message
    });
  }

  const outputGrantAdapter =
    data.outputGrantAdapter ||
    (inventoryStore
      ? new InventoryGrantAdapter({
        inventoryStore,
        itemStore: itemStore || { loadItem: () => null }
      })
      : null);

  if (!outputGrantAdapter || typeof outputGrantAdapter.addDropToInventory !== "function") {
    try {
      inventoryStore.saveInventory(beforeInventory);
    } catch (rollbackError) {
      return createFailure("output_adapter_missing_and_rollback_failed", {
        rollback_error: rollbackError.message
      });
    }
    return createFailure("output_grant_adapter_required");
  }

  const outputs = completion.completion_payload.outputs || [];
  const grantResults = [];
  let grantFailure = null;

  for (const output of outputs) {
    let grantResult;
    try {
      grantResult = outputGrantAdapter.addDropToInventory({
        inventory_id,
        owner_character_id: craftJob.player_id,
        drop: {
          item_id: output.item_id,
          quantity: output.quantity,
          drop_type: "crafted_output"
        }
      });
    } catch (error) {
      grantResult = {
        ok: false,
        reason: "output_grant_threw",
        message: error.message
      };
    }

    grantResults.push({
      item_id: output.item_id,
      quantity: output.quantity,
      result: grantResult
    });

    if (!grantResult || !grantResult.ok) {
      grantFailure = grantResult || { ok: false, reason: "unknown_output_grant_failure" };
      break;
    }
  }

  if (grantFailure) {
    try {
      inventoryStore.saveInventory(beforeInventory);
      return createFailure("output_grant_failed_rolled_back", {
        craft_job_id,
        inventory_id,
        consumed_materials: consumption.consumed_materials,
        grant_results: grantResults,
        grant_failure: grantFailure,
        rollback_applied: true
      });
    } catch (rollbackError) {
      return createFailure("output_grant_failed_and_rollback_failed", {
        craft_job_id,
        inventory_id,
        consumed_materials: consumption.consumed_materials,
        grant_results: grantResults,
        grant_failure: grantFailure,
        rollback_error: rollbackError.message,
        rollback_applied: false
      });
    }
  }

  // Mark craft job finalization safely after output grant success.
  if (data.craftJobStore && typeof data.craftJobStore.load === "function" && typeof data.craftJobStore.save === "function") {
    const storedJob = data.craftJobStore.load(craft_job_id);
    if (storedJob) {
      data.craftJobStore.save({
        ...storedJob,
        status: "completed",
        finalized_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
    }
  }

  if (!allowDuplicate && processedStore && typeof processedStore.add === "function") {
    processedStore.add(finalizationKey);
  }

  return {
    ok: true,
    event_type: "craft_finalize_success",
    payload: {
      finalization_key: String(finalizationKey),
      craft_job_id,
      player_id: String(craftJob.player_id),
      recipe_id: String(recipe.recipe_id),
      inventory_id,
      consumed_materials: consumption.consumed_materials,
      outputs_granted: completion.completion_payload.outputs,
      output_grant_results: grantResults,
      completion_payload: completion.completion_payload,
      finalized_at: new Date().toISOString()
    }
  };
}

module.exports = {
  ProcessedCraftFinalizationStore,
  finalizeCraftWithResourceConsumption
};
