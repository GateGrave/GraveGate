"use strict";

const { handleWorldEventByType } = require("../../world-system/src");

// Placeholder handler for world-level events.
// In Phase 2E this routes character/inventory events into world-state storage and
// emits follow-up result events through the queue.
function handleWorldEvent(event, context) {
  return handleWorldEventByType(event, context);
}

// Placeholder handler for session-level events.
// Session logic is intentionally not implemented in this scaffold.
function handleSessionEvent(event, context) {
  void event;
  void context;
  return [];
}

// Placeholder handler for combat-level events.
// Combat logic is intentionally not implemented in this scaffold.
function handleCombatEvent(event, context) {
  void event;
  void context;
  return [];
}

module.exports = {
  handleWorldEvent,
  handleSessionEvent,
  handleCombatEvent
};
