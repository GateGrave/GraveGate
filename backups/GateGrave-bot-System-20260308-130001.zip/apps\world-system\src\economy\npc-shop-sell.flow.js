"use strict";

class ProcessedNpcShopSellStore {
  constructor() {
    this.processed = new Set();
  }

  has(sell_key) {
    if (!sell_key) return false;
    return this.processed.has(String(sell_key));
  }

  add(sell_key) {
    if (!sell_key) return;
    this.processed.add(String(sell_key));
  }
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function createFailure(reason, extra) {
  return {
    ok: false,
    event_type: "npc_shop_sell_failed",
    payload: {
      reason,
      ...(extra || {})
    }
  };
}

function makeSellKey(data) {
  return (
    data.sell_key ||
    data.event_id ||
    `${data.player_id || "unknown"}:${data.vendor_id || "unknown"}:${data.item_id || "unknown"}:${data.quantity || 0}`
  );
}

function defaultRemoveItemFromInventory(input) {
  const data = input || {};
  const inventoryStore = data.inventoryStore;
  const inventory_id = data.inventory_id;
  const item_id = data.item_id;
  const quantity = data.quantity;

  if (!inventoryStore) {
    return { ok: false, reason: "inventory_store_required" };
  }

  const inventory = inventoryStore.loadInventory(inventory_id);
  if (!inventory) {
    return { ok: false, reason: "inventory_not_found" };
  }

  const entries = Array.isArray(inventory.item_entries) ? inventory.item_entries : [];
  const matchingEntries = entries.filter((x) => x.item_id === item_id);
  if (matchingEntries.length === 0) {
    return { ok: false, reason: "item_not_owned" };
  }

  const totalOwned = matchingEntries.reduce(
    (sum, entry) => sum + (Number.isFinite(entry.quantity) ? Math.floor(entry.quantity) : 1),
    0
  );
  if (totalOwned < quantity) {
    return {
      ok: false,
      reason: "insufficient_item_quantity",
      quantity_owned: totalOwned,
      quantity_requested: quantity
    };
  }

  const before = clone(inventory);
  const workingEntries = clone(entries);

  let remaining = quantity;
  for (const entry of workingEntries) {
    if (entry.item_id !== item_id) continue;
    if (remaining <= 0) break;

    const entryQty = Number.isFinite(entry.quantity) ? Math.max(0, Math.floor(entry.quantity)) : 1;
    if (entryQty <= remaining) {
      entry.quantity = 0;
      remaining -= entryQty;
    } else {
      entry.quantity = entryQty - remaining;
      remaining = 0;
    }
  }

  const next = {
    ...before,
    item_entries: workingEntries.filter((x) => (Number.isFinite(x.quantity) ? x.quantity : 1) > 0)
  };

  inventoryStore.saveInventory(next);
  return {
    ok: true,
    removed_quantity: quantity,
    before_inventory: before,
    after_inventory: next
  };
}

function processNpcShopSell(input) {
  const data = input || {};
  const npcShopManager = data.npcShopManager;
  const currencyManager = data.currencyManager;
  const transactionManager = data.transactionManager;
  const processedSellStore = data.processedSellStore || null;
  const worldStorage = data.worldStorage || null;
  const inventoryStore = worldStorage?.inventories || null;
  const itemStore = worldStorage?.items || null;
  const removeItemFromInventory = data.removeItemFromInventory || defaultRemoveItemFromInventory;

  if (!npcShopManager || !currencyManager || !transactionManager || !inventoryStore || !itemStore) {
    return createFailure("required_manager_missing", {
      requires: ["npcShopManager", "currencyManager", "transactionManager", "worldStorage.inventories", "worldStorage.items"]
    });
  }

  const player_id = data.player_id;
  const vendor_id = data.vendor_id;
  const item_id = data.item_id;
  const quantity = Number.isFinite(data.quantity) ? Math.floor(data.quantity) : NaN;
  const sell_key = makeSellKey(data);
  const inventory_id = data.inventory_id || `inv-${player_id || "unknown"}`;

  if (!player_id || String(player_id).trim() === "") {
    return createFailure("player_id_required");
  }
  if (!vendor_id || String(vendor_id).trim() === "") {
    return createFailure("vendor_id_required");
  }
  if (!item_id || String(item_id).trim() === "") {
    return createFailure("item_id_required");
  }
  if (!Number.isFinite(quantity) || quantity <= 0) {
    return createFailure("invalid_quantity", { quantity_requested: data.quantity });
  }

  if (processedSellStore && typeof processedSellStore.has === "function") {
    if (processedSellStore.has(sell_key)) {
      return {
        ok: true,
        event_type: "npc_shop_sell_skipped",
        payload: {
          reason: "duplicate_sell_key",
          sell_key,
          player_id: String(player_id),
          vendor_id: String(vendor_id),
          item_id: String(item_id),
          quantity
        }
      };
    }
  }

  const shop = npcShopManager.getNpcShop(vendor_id);
  if (!shop) {
    return createFailure("shop_not_found", { vendor_id: String(vendor_id) });
  }
  if (!shop.shop_active) {
    return createFailure("shop_inactive", { vendor_id: String(vendor_id) });
  }

  const itemRecord = itemStore.loadItem(item_id);
  const isSellable =
    data.force_sellable === true
      ? true
      : itemRecord?.sellable === false || itemRecord?.flags?.sellable === false
        ? false
        : true;
  if (!isSellable) {
    return createFailure("item_unsellable", {
      item_id: String(item_id)
    });
  }

  // Step 1: Remove items from inventory.
  let removalResult;
  try {
    removalResult = removeItemFromInventory({
      inventoryStore,
      inventory_id,
      player_id,
      item_id: String(item_id),
      quantity
    });
  } catch (error) {
    return createFailure("inventory_removal_failed", {
      message: error.message
    });
  }

  if (!removalResult || !removalResult.ok) {
    return createFailure("inventory_removal_failed", {
      remove_result: removalResult || null
    });
  }

  // Step 2: Pay gold.
  const basePrice = Number.isFinite(shop.price_map?.[item_id]) ? Math.max(0, Math.floor(shop.price_map[item_id])) : 0;
  const sellRatio = Number.isFinite(data.sell_ratio) ? Math.max(0, data.sell_ratio) : 0.5;
  const goldPerItem =
    Number.isFinite(data.gold_per_item) && data.gold_per_item >= 0
      ? Math.floor(data.gold_per_item)
      : Math.floor(basePrice * sellRatio);
  const payoutGold = goldPerItem * quantity;

  const payoutResult = currencyManager.addCurrency({
    player_id,
    amount: payoutGold,
    currency: "gold",
    reason: "npc_shop_sell",
    source_event_id: data.event_id || null
  });

  if (!payoutResult.ok) {
    // Roll back inventory removal when payout fails.
    if (removalResult.before_inventory) {
      try {
        inventoryStore.saveInventory(removalResult.before_inventory);
      } catch (error) {
        return createFailure("currency_payout_failed_and_inventory_rollback_failed", {
          payout_result: payoutResult,
          rollback_error: error.message
        });
      }
    }
    return createFailure("currency_payout_failed", {
      payout_result: payoutResult
    });
  }

  // Step 3: Optional vendor stock update.
  let stockUpdateStatus = "skipped";
  if (data.add_to_vendor_stock === true) {
    const current = Number.isFinite(shop.quantity_map?.[item_id]) ? Math.floor(shop.quantity_map[item_id]) : 0;
    const stockItems = Array.isArray(shop.stock_items) ? [...shop.stock_items] : [];
    if (!stockItems.includes(String(item_id))) stockItems.push(String(item_id));

    const updated = npcShopManager.updateNpcShop(vendor_id, {
      stock_items: stockItems,
      quantity_map: {
        ...(shop.quantity_map || {}),
        [item_id]: current + quantity
      }
    });
    stockUpdateStatus = updated ? "updated" : "failed_to_update";
  }

  // Step 4: Record transaction.
  const transaction_id =
    data.transaction_id ||
    `txn-shop-sell-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  const transaction = transactionManager.createTransaction({
    transaction_id,
    transaction_type: "npc_shop_sell",
    source_player_id: String(player_id),
    target_player_id: null,
    npc_vendor_id: String(vendor_id),
    item_id: String(item_id),
    quantity,
    gold_amount: payoutGold,
    result: "success"
  });

  if (processedSellStore && typeof processedSellStore.add === "function") {
    processedSellStore.add(sell_key);
  }

  const account = currencyManager.getCurrencyAccount(player_id);
  return {
    ok: true,
    event_type: "npc_shop_sell_success",
    payload: {
      sell_key,
      transaction_id: transaction.transaction_id,
      player_id: String(player_id),
      vendor_id: String(vendor_id),
      item_id: String(item_id),
      quantity,
      gold_earned: payoutGold,
      gold_balance_after: account?.gold_balance ?? null,
      inventory_id,
      stock_update_status: stockUpdateStatus,
      sell_result: "success",
      processed_at: new Date().toISOString()
    }
  };
}

module.exports = {
  ProcessedNpcShopSellStore,
  processNpcShopSell,
  defaultRemoveItemFromInventory
};

