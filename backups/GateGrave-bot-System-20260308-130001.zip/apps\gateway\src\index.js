"use strict";

const { createEvent, EVENT_TYPES } = require("../../../packages/shared-types");

// Gateway Placeholder (Phase 1)
// This module is only a translator:
// - It accepts external input shapes (slash commands, button clicks)
// - It converts them into internal JSON events
// - It pushes those events to the queue
// It does NOT run gameplay rules or combat calculations.

function createGatewayContext(mockInput, targetSystem) {
  return {
    source: "gateway",
    target_system: targetSystem || "session",
    player_id: mockInput.authorId || null,
    session_id: mockInput.sessionId || null,
    combat_id: mockInput.combatId || null
  };
}

function simulateSlashCommands(mockInput) {
  return [
    {
      kind: "slash_command",
      name: "move",
      options: { direction: "north", steps: 1 },
      context: mockInput
    },
    {
      kind: "slash_command",
      name: "attack",
      options: { target_id: "enemy-01", weapon: "sword" },
      context: mockInput
    },
    {
      kind: "slash_command",
      name: "cast_spell",
      options: { spell_name: "magic_missile", target_id: "enemy-01" },
      context: mockInput
    }
  ];
}

function simulateButtonClicks(mockInput) {
  return [
    {
      kind: "button_click",
      action: "use_item",
      data: { item_id: "health_potion_small", target_id: mockInput.authorId },
      context: mockInput
    }
  ];
}

function convertGatewayInputToEvent(input) {
  const ctx = input.context || {};

  if (input.kind === "slash_command" && input.name === "move") {
    return createEvent(
      EVENT_TYPES.PLAYER_MOVE,
      input.options,
      createGatewayContext(ctx, "session")
    );
  }

  if (input.kind === "slash_command" && input.name === "attack") {
    return createEvent(
      EVENT_TYPES.PLAYER_ATTACK,
      input.options,
      createGatewayContext(ctx, "combat")
    );
  }

  if (input.kind === "slash_command" && input.name === "cast_spell") {
    return createEvent(
      EVENT_TYPES.PLAYER_CAST_SPELL,
      input.options,
      createGatewayContext(ctx, "combat")
    );
  }

  if (input.kind === "button_click" && input.action === "use_item") {
    return createEvent(EVENT_TYPES.PLAYER_USE_ITEM, input.data, createGatewayContext(ctx, "world"));
  }

  return null;
}

function createGatewayEventsFromMockInputs(mockInput) {
  const rawInputs = [
    ...simulateSlashCommands(mockInput),
    ...simulateButtonClicks(mockInput)
  ];

  const events = [];

  for (const input of rawInputs) {
    const event = convertGatewayInputToEvent(input);
    if (event) {
      events.push(event);
    }
  }

  return events;
}

function sendEventsToQueue(queue, events) {
  for (const event of events) {
    queue.enqueue(event);
  }
}

function gatewayTick(queue, mockInput) {
  const events = createGatewayEventsFromMockInputs(mockInput);
  sendEventsToQueue(queue, events);
  return events;
}

// Backward-compatible name used by current root bootstrap.
function createExampleEventsFromMockDiscordInput(mockInput) {
  return createGatewayEventsFromMockInputs(mockInput);
}

module.exports = {
  simulateSlashCommands,
  simulateButtonClicks,
  convertGatewayInputToEvent,
  createGatewayEventsFromMockInputs,
  sendEventsToQueue,
  gatewayTick,
  createExampleEventsFromMockDiscordInput
};
