"use strict";

const { EVENT_TYPES, isValidEvent } = require("../../../packages/shared-types");
const {
  handleWorldEvent,
  handleSessionEvent,
  handleCombatEvent
} = require("./handlers");

// Event Router exists so systems stay decoupled.
// Systems do not call each other directly.
// They only emit events, and the router decides where each event goes.
class EventRouter {
  constructor() {
    this.routes = new Map();
  }

  /**
   * Optional extension point for later phases.
   * Allows event_type-specific handlers to be attached without coupling systems.
   * @param {string} eventType
   * @param {Function} handler
   */
  register(eventType, handler) {
    if (!this.routes.has(eventType)) {
      this.routes.set(eventType, []);
    }

    this.routes.get(eventType).push(handler);
  }

  /**
   * Inspect one event and route it to a placeholder system handler.
   * @param {object} event
   * @param {object} context
   */
  route(event, context) {
    if (!isValidEvent(event)) {
      throw new Error("EventRouter.route received an invalid event object");
    }

    const system = this.resolveSystem(event);
    const logger = context.logger;

    if (logger) {
      logger.logRoute(event, system);
    }

    const systemEvents = this.routeToSystemStub(event, context, system) || [];
    let generatedEvents = 0;
    generatedEvents += this.enqueueAll(systemEvents, context);

    const typedHandlers = this.routes.get(event.event_type) || [];
    for (const handler of typedHandlers) {
      const nextEvents = handler(event, context) || [];
      generatedEvents += this.enqueueAll(nextEvents, context);
    }

    return {
      system,
      generated_events: generatedEvents
    };
  }

  /**
   * Route to one of the three Phase 1 system stubs:
   * - world
   * - session
   * - combat
   */
  routeToSystemStub(event, context, system) {
    if (system === "world") {
      return handleWorldEvent(event, context);
    }

    if (system === "session") {
      return handleSessionEvent(event, context);
    }

    if (system === "combat") {
      return handleCombatEvent(event, context);
    }

    return [];
  }

  /**
   * Pick the target system for the event.
   * Prefer event.target_system. If missing/unknown, infer by event_type.
   */
  resolveSystem(event) {
    const directTarget = event.target_system;
    if (directTarget === "world" || directTarget === "session" || directTarget === "combat") {
      return directTarget;
    }

    const byType = {
      [EVENT_TYPES.CHARACTER_CREATED]: "world",
      [EVENT_TYPES.CHARACTER_UPDATED]: "world",
      [EVENT_TYPES.LEVEL_UP]: "world",
      [EVENT_TYPES.ITEM_ADDED]: "world",
      [EVENT_TYPES.ITEM_REMOVED]: "world",
      [EVENT_TYPES.ITEM_EQUIPPED]: "world",
      [EVENT_TYPES.ITEM_UNEQUIPPED]: "world",
      [EVENT_TYPES.PLAYER_USE_ITEM]: "world",
      [EVENT_TYPES.PLAYER_MOVE]: "session",
      [EVENT_TYPES.LOOT_GENERATED]: "session",
      [EVENT_TYPES.PLAYER_ATTACK]: "combat",
      [EVENT_TYPES.COMBAT_STARTED]: "combat"
    };

    return byType[event.event_type] || "session";
  }

  /**
   * Queue any events returned by handlers.
   */
  enqueueAll(events, context) {
    let count = 0;

    for (const nextEvent of events) {
      if (!isValidEvent(nextEvent)) {
        throw new Error("Handler returned an invalid event object");
      }

      context.queue.enqueue(nextEvent);
      count += 1;
    }

    return count;
  }
}

module.exports = {
  EventRouter
};
