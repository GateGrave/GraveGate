"use strict";

// Shared event type constants for Phase 1 scaffolding.
// Keep these names stable so routing stays simple and predictable.
const EVENT_TYPES = {
  // Required examples for the shared format scaffold.
  PLAYER_MOVE: "player_move",
  PLAYER_ATTACK: "player_attack",
  COMBAT_STARTED: "combat_started",
  LOOT_GENERATED: "loot_generated",

  // Extra scaffold events used by current placeholder modules.
  PLAYER_CAST_SPELL: "player_cast_spell",
  PLAYER_USE_ITEM: "player_use_item",
  CHARACTER_CREATED: "character_created",
  CHARACTER_UPDATED: "character_updated",
  LEVEL_UP: "level_up",
  ITEM_ADDED: "item_added",
  ITEM_REMOVED: "item_removed",
  ITEM_EQUIPPED: "item_equipped",
  ITEM_UNEQUIPPED: "item_unequipped",
  WORLD_ACTION_RESULT: "world_action_result",
  DATABASE_EVENT_SAVED: "database_event_saved"
};

module.exports = {
  EVENT_TYPES
};
