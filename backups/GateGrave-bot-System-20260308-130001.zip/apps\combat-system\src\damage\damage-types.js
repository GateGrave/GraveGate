"use strict";

// Initial typed damage list for Phase damage pipeline.
const DAMAGE_TYPES = {
  FIRE: "fire",
  COLD: "cold",
  SLASHING: "slashing",
  NECROTIC: "necrotic"
};

module.exports = {
  DAMAGE_TYPES
};
