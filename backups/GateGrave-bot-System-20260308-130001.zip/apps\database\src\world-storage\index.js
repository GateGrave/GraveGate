"use strict";

const {
  InMemoryCharacterStore,
  mockCharacterSaveLoadExample
} = require("./characters.store");
const {
  InMemoryInventoryStore,
  mockInventorySaveLoadExample
} = require("./inventories.store");
const {
  InMemoryItemStore,
  mockItemSaveLoadExample
} = require("./items.store");

module.exports = {
  InMemoryCharacterStore,
  InMemoryInventoryStore,
  InMemoryItemStore,
  mockExamples: {
    characters: mockCharacterSaveLoadExample,
    inventories: mockInventorySaveLoadExample,
    items: mockItemSaveLoadExample
  }
};
